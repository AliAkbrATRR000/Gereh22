package com.gereh.p2p;

import android.Manifest;
import android.net.Uri;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import androidx.activity.result.ActivityResultLauncher;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int PORT = 8988;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newCachedThreadPool();

    private EditText nameInput, hostInput, messageInput;
    private TextView status, chat;
    private ImageView qr;
    private Button listenButton, connectButton, sendButton;
    private ServerSocket serverSocket;
    private Socket peer;
    private BufferedWriter writer;
    private String myName;
    private final String deviceId = UUID.randomUUID().toString().substring(0, 8);

    private final ActivityResultLauncher<ScanOptions> scanner =
        registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null) {
                String raw = result.getContents();
                try {
                    UriData d = parseCard(raw);
                    hostInput.setText(d.host);
                    append("کارت «" + d.name + "» اسکن شد. برای اتصال، آدرس را بررسی و دکمه اتصال را بزن.");
                } catch (Exception e) {
                    append("QR معتبر گره نیست.");
                }
            }
        });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 7);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 30, 36, 30);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(246,246,248));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("گره  •  GEREH");
        title.setTextSize(28); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        nameInput = edit("نام مستعار (مثلاً ali)");
        root.addView(nameInput, matchWrap());

        Button makeCard = button("ساخت کارت و QR من");
        root.addView(makeCard, matchWrap());
        qr = new ImageView(this);
        qr.setAdjustViewBounds(true);
        root.addView(qr, new LinearLayout.LayoutParams(560, 560));
        status = new TextView(this);
        status.setText("برای ارتباط مستقیم، آدرس IP عمومی قابل دسترس لازم است.");
        status.setTextSize(14); status.setTextColor(Color.DKGRAY);
        root.addView(status, matchWrap());

        listenButton = button("شروع انتظار برای اتصال");
        root.addView(listenButton, matchWrap());
        hostInput = edit("IP عمومی مخاطب (IPv4 یا IPv6)");
        root.addView(hostInput, matchWrap());
        Button scan = button("اسکن کارت مخاطب");
        root.addView(scan, matchWrap());
        connectButton = button("اتصال مستقیم");
        root.addView(connectButton, matchWrap());

        chat = new TextView(this);
        chat.setText("گفتگو خالی است.");
        chat.setTextSize(15); chat.setTextColor(Color.BLACK);
        chat.setPadding(8,24,8,24);
        root.addView(chat, matchWrap());
        messageInput = edit("پیام متنی");
        root.addView(messageInput, matchWrap());
        sendButton = button("ارسال پیام");
        root.addView(sendButton, matchWrap());

        setContentView(scroll);

        makeCard.setOnClickListener(v -> createCard());
        listenButton.setOnClickListener(v -> startListening());
        scan.setOnClickListener(v -> {
            ScanOptions options = new ScanOptions();
            options.setPrompt("کارت QR گره را اسکن کنید");
            options.setBeepEnabled(false);
            options.setOrientationLocked(true);
            scanner.launch(options);
        });
        connectButton.setOnClickListener(v -> connectToPeer());
        sendButton.setOnClickListener(v -> sendMessage());
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(16); e.setSingleLine(true);
        e.setPadding(18,12,18,12);
        return e;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); return b;
    }
    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8); return p;
    }

    private void createCard() {
        myName = nameInput.getText().toString().trim();
        if (myName.isEmpty() || myName.contains(":")) {
            status.setText("یک نام ساده وارد کن؛ از : استفاده نکن.");
            return;
        }
        // The user must supply a reachable public address manually.
        String card = "gereh://connect?name=" + Uri.encode(myName) +
                "&id=" + deviceId + "&port=" + PORT;
        try {
            BitMatrix matrix = new MultiFormatWriter().encode(card, BarcodeFormat.QR_CODE, 600, 600);
            Bitmap bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565);
            for (int x=0; x<600; x++) for (int y=0; y<600; y++)
                bitmap.setPixel(x,y,matrix.get(x,y) ? Color.BLACK : Color.WHITE);
            qr.setImageBitmap(bitmap);
            status.setText("شناسه: " + myName + ":" + deviceId +
                    "\nاین QR فقط نام و شناسه را دارد؛ IP عمومی را جداگانه به مخاطب بده.");
        } catch (Exception e) { status.setText("ساخت QR ناموفق بود: " + e.getMessage()); }
    }

    private void startListening() {
        if (serverSocket != null && !serverSocket.isClosed()) {
            status.setText("در حال انتظار روی پورت " + PORT); return;
        }
        io.execute(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                main.post(() -> status.setText("در حال انتظار روی پورت " + PORT +
                        "\nIP عمومی قابل دسترس را باید جداگانه با مخاطب به اشتراک بگذاری."));
                Socket s = serverSocket.accept();
                attach(s);
            } catch (Exception e) {
                main.post(() -> status.setText("خطای دریافت اتصال: " + e.getMessage()));
            }
        });
    }

    private void connectToPeer() {
        String host = hostInput.getText().toString().trim();
        if (host.isEmpty()) { status.setText("ابتدا IP عمومی مخاطب را وارد کن."); return; }
        io.execute(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(host, PORT), 12000);
                attach(s);
            } catch (Exception e) {
                main.post(() -> status.setText("اتصال ناموفق: " + e.getMessage() +
                        "\nممکن است شبکه اتصال مستقیم یا پورت ورودی را مسدود کرده باشد."));
            }
        });
    }

    private synchronized void attach(Socket s) throws IOException {
        peer = s;
        writer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
        main.post(() -> status.setText("متصل شد: " + s.getRemoteSocketAddress()));
        io.execute(() -> {
            try {
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                String line;
                while ((line = reader.readLine()) != null) {
                    final String received = line;
                    main.post(() -> append("مخاطب: " + received));
                }
            } catch (Exception e) {
                main.post(() -> status.setText("ارتباط قطع شد."));
            }
        });
    }

    private void sendMessage() {
        String message = messageInput.getText().toString().trim();
        if (message.isEmpty()) return;
        io.execute(() -> {
            try {
                BufferedWriter w = writer;
                if (w == null || peer == null || peer.isClosed()) throw new IOException("اتصال برقرار نیست");
                synchronized (this) {
                    w.write(message.replace("\n", " "));
                    w.newLine(); w.flush();
                }
                main.post(() -> { append("من: " + message); messageInput.setText(""); });
            } catch (Exception e) {
                main.post(() -> status.setText("ارسال نشد: " + e.getMessage()));
            }
        });
    }

    private void append(String line) {
        chat.append("\n" + line);
    }

    private UriData parseCard(String raw) {
        if (!raw.startsWith("gereh://connect?")) throw new IllegalArgumentException();
        String query = raw.substring(raw.indexOf('?')+1);
        String name = "";
        for (String part : query.split("&")) {
            String[] kv = part.split("=",2);
            if (kv.length == 2 && kv[0].equals("name")) name = URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
        }
        if (name.isEmpty()) throw new IllegalArgumentException();
        return new UriData(name, "");
    }
    private static class UriData {
        String name, host;
        UriData(String n, String h) { name=n; host=h; }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if (peer != null) peer.close(); } catch (Exception ignored) {}
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        io.shutdownNow();
    }
}
